BASEDIR=$(cd $(dirname $0); pwd)
processing-java --sketch=$BASEDIR --output=$BASEDIR/bin --present --force
